#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
from pathlib import Path
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.prompt import Prompt

console = Console()

# Nama folder tempat tool berada
TOOL_FOLDER = "lib"  # <-- ubah kalau foldernya beda nama

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def print_header():
    clear_screen()
    console.print(Panel.fit(
        "[bold magenta]WEBSHELL & GRABBER PANEL[/bold magenta]\n"
        "[dim]2026 • Ethical Use Only[/dim]",
        border_style="bright_blue",
        padding=(1, 4)
    ))

def run_shellfinder():
    script_path = Path(TOOL_FOLDER) / "shellfinder.py"
    
    if not script_path.is_file():
        console.print(f"[red]File tidak ditemukan: {script_path}[/red]")
        console.print("[yellow]Pastikan shellfinder.py ada di folder '{TOOL_FOLDER}/'[/yellow]")
        Prompt.ask("\nTekan Enter untuk kembali...", default="")
        return

    # Langsung jalankan tanpa embel-embel
    original_dir = os.getcwd()
    try:
        os.chdir(TOOL_FOLDER)
        os.system(f"{sys.executable} shellfinder.py")
    finally:
        os.chdir(original_dir)

def run_grabber():
    script_path = Path(TOOL_FOLDER) / "grabber.py"
    
    if not script_path.is_file():
        console.print(f"[red]File tidak ditemukan: {script_path}[/red]")
        Prompt.ask("\nTekan Enter untuk kembali...", default="")
        return

    console.print(Panel(f"[bold red]MEMASUKI MODE GRABBER...[/bold red]", border_style="red"))
    
    # Animasi loading (tetap dipertahankan untuk grabber)
    spinner = ['⣾', '⣷', '⣯', '⣟', '⡿', '⢿', '⣻', '⣽']
    print("\033[36mMemuat...", end="", flush=True)
    for i in range(15):
        print(f"\r\033[36mMemuat... {spinner[i % len(spinner)]}\033[0m", end="", flush=True)
        import time; time.sleep(0.1)
    print("\r" + " " * 35 + "\r", end="", flush=True)
    print("\033[32mSiap!\033[0m\n")

    original_dir = os.getcwd()
    try:
        os.chdir(TOOL_FOLDER)
        console.print(f"[dim]Berpindah ke: {os.getcwd()}[/dim]")
        os.system(f"{sys.executable} grabber.py")
    except Exception as e:
        console.print(f"[red]Gagal menjalankan grabber: {e}[/red]")
    finally:
        os.chdir(original_dir)
        console.print(f"[dim]Kembali ke: {os.getcwd()}[/dim]")

    Prompt.ask("\n[cyan]Tekan Enter untuk kembali ke menu[/cyan]", default="")

def show_menu():
    while True:
        print_header()
        
        table = Table(show_header=False, expand=True, border_style="dim")
        table.add_column("No", style="cyan", width=6)
        table.add_column("Menu", style="white")
        
        table.add_row("1", "Shell Finder")
        table.add_row("2", "Grabber")
        table.add_row("0", "Keluar")
        
        console.print(table)
        console.print()

        choice = Prompt.ask(
            "[bold green]Pilih[/bold green]",
            choices=["0", "1", "2"],
            default="1"
        )

        if choice == "1":
            run_shellfinder()           # ← hanya redirect langsung ke shellfinder.py
        elif choice == "2":
            run_grabber()
        elif choice == "0":
            console.print("\n[yellow]Keluar dari panel. Stay safe![/yellow]")
            sys.exit(0)

if __name__ == "__main__":
    try:
        show_menu()
    except KeyboardInterrupt:
        console.print("\n[yellow]Dihentikan oleh user.[/yellow]")
    except Exception as e:
        console.print(f"[red]Error di panel: {e}[/red]")